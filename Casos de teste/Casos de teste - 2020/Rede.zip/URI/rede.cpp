// Solucao do problema Rede de Agua via algoritmo de Prim
// Prof. Andre da Cruz - andre.cruz@ifsp.edu.br
// III InterIF

#include <iostream>
#include <vector>
#include <queue>
#include <utility>

using namespace std;

vector<vector<pair<int, int>>> ladj; //lista de adjacencia [origem][destino][peso]
vector<bool> incluso;                //vertices incluidos na agm
priority_queue<pair<int, int>> fp;   //fila de prioridade

void processa(int u) {
    incluso[u] = true;
    for(unsigned j = 0; j < ladj[u].size(); j++) {
        pair<int, int> v = ladj[u][j];
        if(!incluso[v.first])
            fp.push(make_pair(-v.second, -v.first));
    }
}

int main() {
    int n, m, u, v, w, i, custo = 0;

    //le numero de vertices e arestas, aloca lista de adjacencia e a preenche
    cin >> n >> m;
    ladj.resize(n+1);
    for(i = 0; i < m; i++) {
        cin >> u >> v >> w;
        ladj[u].push_back(make_pair(v, w));
        ladj[v].push_back(make_pair(u, w));
    }

    incluso.assign(n+1, false); //nenhum vertice na agm
    processa(1);                //inclui um vertice inicial
    while(!fp.empty()){
        //remove vertice do topo da fila de prioridade
        pair<int, int> frente = fp.top();
        fp.pop();

        //vertice e peso
        u = -frente.second;
        w = -frente.first;

        //se nao incluido, o inclui e processa adjacentes
        if(!incluso[u]) {
            custo += w;
            processa(u);
        }
    }

    cout << custo << endl;

    return 0;
}