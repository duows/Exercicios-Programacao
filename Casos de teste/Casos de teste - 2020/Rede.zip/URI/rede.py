# Solucao do problema Rede de Agua via algoritmo de Prim
# Prof. Andre da Cruz - andre.cruz@ifsp.edu.br
# III InterIF

import heapq as pq

#processa vertice candidato a entrar na agm
def processa(ladj, u, incluso, fp):
    incluso[u] = True
    for v, w in ladj[u]:
        if not incluso[v]:
            pq.heappush(fp, (w, v)) #insere na fila de prioridade

custo = 0
n, m = [int(x) for x in input().split()]

#cria grafo (lista de adjacencia) vazio e o preenche
ladj = [[] for _ in range(n+1)]
for i in range(m):
    u, v, w = [int(x) for x in input().split()]
    ladj[u].append((v, w))
    ladj[v].append((u, w))

#inicializa vetor de inclusao, fila de prioridade e insere primeiro vertice na agm
incluso = [False for _ in range(n+1)]
fp = []
processa(ladj, 1, incluso, fp)

while fp:
    w, u = pq.heappop(fp)
    if not incluso[u]:
        custo += w
        processa(ladj, u, incluso, fp)

print(custo)