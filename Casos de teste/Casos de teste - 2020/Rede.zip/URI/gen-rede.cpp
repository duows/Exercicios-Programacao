#include <iostream>
#include <vector>
#include <utility>
#include <random>
#include <algorithm>

using namespace std;

int main() {
    vector<vector<pair<int, int>>> l_adj;
    int num_vertices, num_arestas, num_origens, num_destinos;
    int niveis, vertices_por_nivel;
    int i, j, k, l, ob;
    random_device rd;
    uniform_int_distribution<int> unif_int(10, 100);
    uniform_real_distribution<double> unif_dbl(0, 1);
    int testes, t;

    testes = 1;// 1 + unif_int(rd)%10;

    //cout << testes << endl;
    for(t = 0; t < testes; t++) {
        num_origens = 1 + unif_int(rd)%10;
        num_destinos = 1 + unif_int(rd)%10;
        niveis = 1 + unif_int(rd)%5;
        vertices_por_nivel = 1 + unif_int(rd)%10;

        //numero de vertices
        num_vertices = 100;//num_origens + num_destinos + niveis*vertices_por_nivel;
        l_adj.resize(num_vertices+1);

        // num_arestas = vertices_por_nivel*(num_origens + num_destinos + vertices_por_nivel-1);
        num_arestas = 0;

        //vertices saindo das fontes (ha todos)
        for(i = 1; i <= num_origens; i++){
            ob = num_origens+1 + unif_int(rd) % vertices_por_nivel;
            for(j = num_origens+1; j <= num_origens+vertices_por_nivel; j++){
                l_adj[i].push_back({j, unif_int(rd)});
                num_arestas++;
            }
        }

        //vertices saindo de um nivel intermediario a outro  (ha pelo menos de cada)
        for(k = 1; k < niveis; k++) {
            l = i + vertices_por_nivel;
            for(; i < l; i++){
                ob = i+1 + unif_int(rd) % vertices_por_nivel;
                for(j = l; j < l+vertices_por_nivel; j++) {
                    if(unif_dbl(rd) <= 0.5 || j == ob) {
                        l_adj[i].push_back({j, unif_int(rd)});
                        num_arestas++;
                    }
                }
            }
        }

        //vertices chegando no sorvedouro (ha todos)
        k = i+vertices_por_nivel-1;
        for(; i <= k; i++) {
            ob = i+1 + unif_int(rd) % vertices_por_nivel;
            for(j = k+1; j <= num_vertices; j++) {
                l_adj[i].push_back({j, unif_int(rd)});
                num_arestas++;
            }
        }

        //saida do arquivo de entrada
        cout << num_vertices << " " << num_arestas << endl;
        
        // for(i = 1; i < num_origens; i++) cout << i << " ";
        // cout << num_origens << endl;

        // for(i = num_vertices-num_destinos+1; i < num_vertices; i++) cout << i << " ";
        // cout << num_vertices << endl;



        for(i = 1; i < num_vertices; i++) {
            for(j = 0; j < (int)l_adj[i].size(); j++) {
                cout << i << " " << l_adj[i][j].first << " " << l_adj[i][j].second << endl;
            }
        }

        for(i = 0; i < (int)l_adj.size(); i++) l_adj[i].clear();
        l_adj.clear();
    }

    return 0;
}