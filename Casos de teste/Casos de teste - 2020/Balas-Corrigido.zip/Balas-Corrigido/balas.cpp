// Solucao do problema Balas e Doces
// Prof. Andre da Cruz - andre.cruz@ifsp.edu.br
// III InterIF

#include <iostream>

using namespace std;

int main() {
    unsigned long b, d;

    cin >> b >> d;
    cout << b+d << endl;
    
    return 0;
}
