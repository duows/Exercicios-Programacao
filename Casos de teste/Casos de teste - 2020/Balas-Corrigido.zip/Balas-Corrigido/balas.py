# Solucao do problema Balas e Doces
# Prof. Andre da Cruz - andre.cruz@ifsp.edu.br
# III InterIF

a = int(input())
b = int(input())
print(a+b)
