
import java.util.Scanner;
import java.util.Locale;

/**
 * Instituto Federal de S�o Paulo - IFSP - Campus Catanduva
 * 
 * Maratona da Programa��o 2020 
 * Prof. Luis Hideo Vasconcelos Nakamura
 * 
*/
public class RiscoDeMorte {

    public static void main(String[] args) {

		Locale.setDefault(Locale.US);
	
		char sexo; //H ou M
		int idade; //idade
		char cor; //cor
		int renda; //renda
    
		float sexo_p = 0, idade_p = 0, cor_p = 0, renda_p = 0;
		float resultado = 0;

        Scanner in = new Scanner(System.in);
		sexo = in.next().charAt(0);
        idade = in.nextInt();
        cor = in.next().charAt(0);
        renda = in.nextInt();

		if(sexo == 'H') {
		  sexo_p = 58.0f;
		}
		else if(sexo == 'M') {
			sexo_p = 42.0f;
		}
		else {
			 System.out.printf ("Valor Sexo invalido!\n");
			 
		}
		
		
		if(idade <= 14) {
			idade_p = 1.0f;
		}
		else if(idade >= 15 && idade <= 29) {
			 idade_p = 5.0f;
		}
		else if(idade >= 30 && idade <= 39) {
			 idade_p = 10.0f;
		}
		else if(idade >= 40 && idade <= 49) {
			 idade_p = 15.0f;
		}
		else if(idade >= 50 && idade <= 59) {
			 idade_p = 20.0f;
		} 
		else if(idade >= 60 && idade <= 69) {
			 idade_p = 24.0f;
		}
		else if(idade >= 70) {
			 idade_p = 25.0f;
		}
		else
		{
			System.out.printf("Valor Idade invalido!\n");
			
		}
		
		if(cor == 'P') {
		  cor_p = 50.0f;
		}
		else if(cor == 'B') {
			cor_p = 36.0f;
		}
		else if(cor == 'A') {
			cor_p = 14.0f;
		}
		else {
			 System.out.printf("Valor Cor invalido!\n");
			 
		}
		
		if(renda <= 3000) {
			 renda_p = 66.0f;
		}
		else if(renda >= 3001 && renda <= 6500) {
			 renda_p = 21.0f;
		}
		else if(renda > 6500) {
			 renda_p = 13.0f;
		}
		else
		{
			System.out.printf("Valor Renda invalido!\n");
		   
		}    
		
		//System.out.printf("Sexo %f\n", sexo_p);
		//System.out.printf("Idade %f\n", idade_p);
		//System.out.printf("Cor %f\n", cor_p);
		//System.out.printf("Renda %f\n", renda_p);
	   
		resultado = calcProb(sexo_p, idade_p, cor_p, renda_p);
		
		System.out.printf("%.2f", resultado); 
            
        
    }

    private static float calcProb (float sexoP, float idadeP, float corP, float rendaP)
	{
		float prob;           

		prob = (((sexoP/100 * idadeP/100 * corP/100 * rendaP/100) * 0.001f) * 200000000.0f);   
			
		return prob;
	}

  
}
