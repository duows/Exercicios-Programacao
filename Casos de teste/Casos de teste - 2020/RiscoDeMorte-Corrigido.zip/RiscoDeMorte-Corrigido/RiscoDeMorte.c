/**
* Instituto Federal de S�o Paulo - IFSP - Campus Catanduva
*
* Maratona da Programa��o 2020
* Prof. Luis Hideo Vasconcelos Nakamura
*
*/
#include <stdio.h>
#include <stdlib.h>

float calcProb (float sexoP, float idadeP, float corP, float rendaP)
{
      float prob;           
      
      prob = (((sexoP/100 * idadeP/100 * corP/100 * rendaP/100) * 0.001) * 200000000.0);  
            
      return prob;
}


int main(int argc, char *argv[])
{
    char sexo; //H ou M
    int idade; //idade
    char cor; //cor
    int renda; //renda
    
    float sexo_p = 0, idade_p = 0, cor_p = 0, renda_p = 0;
    float resultado = 0;
        
    scanf("%c %d %c %d", &sexo, &idade, &cor, &renda);
    
    //printf("Sexo %c\n", sexo);
    //printf("Idade %d\n", idade);
    //printf("Cor %c\n", cor);
    //printf("Renda %d\n", renda);
        
    if(sexo == 'H') {
      sexo_p = 58.0;
    }
    else if(sexo == 'M') {
        sexo_p = 42.0;
    }
    else {
         printf ("Valor Sexo invalido!\n");
         
    }
    
    
    if(idade <= 14) {
        idade_p = 1.0;
    }
    else if(idade >= 15 && idade <= 29) {
         idade_p = 5.0;
    }
    else if(idade >= 30 && idade <= 39) {
         idade_p = 10.0;
    }
    else if(idade >= 40 && idade <= 49) {
         idade_p = 15.0;
    }
    else if(idade >= 50 && idade <= 59) {
         idade_p = 20.0;
    } 
    else if(idade >= 60 && idade <= 69) {
         idade_p = 24.0;
    }
    else if(idade >= 70) {
         idade_p = 25.0;
    }
    else
    {
        printf ("Valor Idade invalido!\n");
        
    }
    
    if(cor == 'P') {
      cor_p = 50.0;
    }
    else if(cor == 'B') {
        cor_p = 36.0;
    }
    else if(cor == 'A') {
        cor_p = 14.0;
    }
    else {
         printf ("Valor Cor invalido!\n");
         
    }
    
    if(renda <= 3000) {
         renda_p = 66.0;
    }
    else if(renda >= 3001 && renda <= 6500) {
         renda_p = 21.0;
    }
    else if(renda > 6500) {
         renda_p = 13.0;
    }
    else
    {
        printf ("Valor Renda invalido!\n");
       
    }    
    
    //printf("Sexo %f\n", sexo_p);
    //printf("Idade %f\n", idade_p);
    //printf("Cor %f\n", cor_p);
    //printf("Renda %f\n", renda_p);
   
    resultado = calcProb(sexo_p, idade_p, cor_p, renda_p);
    
    printf ("%.2f\n", resultado);
    
    
  return 0;
}
