#include <stdio.h>
#include <math.h>
#include <stdbool.h>
#include <float.h>
#define MAX_USER 500

typedef struct
{
  float x;
  float y;
} PONTO;

float distancia (PONTO *a, PONTO *b)
{
  float dx, dy;
  dx = a->x - b->x;
  dy = a->y - b->y;
  return (sqrt(dx * dx + dy * dy));
}

int main()
{
  double distancias[MAX_USER][MAX_USER];
  float processado[MAX_USER];
  PONTO pontos[MAX_USER];
  float similaridade[MAX_USER / 2];
  float minimo, soma;
  int npontos, p1, p2;

  scanf ("%d", &npontos);

  for (int ponto = 0; ponto < npontos; ponto++)
  {
    scanf("%f %f", &pontos[ponto].x, &pontos[ponto].y);
    processado[ponto] = false;
  }

  for (int linha = 0; linha < npontos; linha++)
    for (int coluna = linha + 1; coluna < npontos; coluna++)
      distancias[linha][coluna] = distancia(&pontos[linha], &pontos[coluna]);

  for (int par = 0; par < npontos / 2; par++)
  {
    minimo = FLT_MAX;
    for (int linha = 0; linha < npontos; linha++)
    {
      for (int coluna = linha+1; coluna < npontos; coluna++)
      {
        if ((distancias[linha][coluna] < minimo) && (!processado[linha]) && (!processado[coluna]))
        {
          minimo = distancias[linha][coluna];
          p1 = linha;
          p2 = coluna;
        }
      }
    }
    processado[p1] = true;
    processado[p2] = true;
    similaridade[par] = distancia(&pontos[p1], &pontos[p2]);
  }

  soma = 0;
  for (int par = 0; par < npontos / 2; par++)
  {
    soma = soma + similaridade[par];
  }
  printf("%.2f\n", soma);
  return 0;
}
