#include <iostream>
#include <string>

using namespace std;	
		
int main(){
		string nomeX,nomeO;
		char tab[3][3];
		int i, j;
		//Leitura dos nomes dos alunos
		cin>>nomeX;
		cin>>nomeO;
		//Separando os nomes
		nomeX = nomeX.substr(2,nomeX.size());
		nomeO = nomeO.substr(2,nomeO.size());
		//Armazenamento dos s�mbolos na matriz
		for(i = 0; i < 3; i++){
				cin>>tab[i][0]>>tab[i][1]>>tab[i][2];
		}
		//Compara��es de jogadas usando os simbolos X e O
		if(tab[0][0] =='X' && tab[0][1] =='X' && tab[0][2] =='X' || tab[1][0] =='X' && tab[1][1] =='X' && tab[1][2] =='X' ||
		tab[2][0] =='X'  && tab[2][1] =='X' && tab[2][2] =='X' || tab[0][0] =='X' && tab[1][0] =='X' && tab[2][0] =='X' || 
		tab[0][1] =='X' && tab[1][1] =='X' && tab[2][1] =='X' ||  tab[0][2] =='X' && tab[1][2] =='X' && tab[2][2] =='X' ||
		tab[0][0] =='X' && tab[1][1] =='X' && tab[2][2] =='X' ||  tab[0][2] =='X' && tab[1][1] =='X' && tab[2][0] =='X'){	
			cout<<nomeX<<" Ganhou\n";	
		}else if(tab[0][0] =='O' && tab[0][1] =='O' && tab[0][2] =='O' || tab[1][0] =='O' && tab[1][1] =='O' && tab[1][2] =='O' ||
		tab[2][0] =='O' && tab[2][1] =='O' && tab[2][2] =='O' || tab[0][0] =='O' && tab[1][0] =='O' && tab[2][0] =='O' || 
		tab[0][1] =='O' && tab[1][1] =='O' && tab[2][1] =='O' ||  tab[0][2] =='O' && tab[1][2] =='O' && tab[2][2] =='O' ||
		tab[0][0] =='O' && tab[1][1] =='O' && tab[2][2] =='O' ||  tab[0][2] =='O' && tab[1][0] =='O' && tab[2][0] =='O'){
				cout<<nomeO<<" Ganhou\n";
		}else{
			cout<<"Empatou!\n";
		}
		return 0;
	}
