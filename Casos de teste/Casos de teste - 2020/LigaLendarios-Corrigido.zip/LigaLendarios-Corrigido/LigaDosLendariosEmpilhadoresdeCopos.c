#include <stdio.h>
#include <stdlib.h>

//9^8=43046721;

int main()
{
    int n,i;
    int resc=0, rese=0; //resultado correto, resultado errado
    int resp;
    int aux; //variavel auxiliar para o c�lculo
    int valor;
    char op;

    scanf("%d",&n);
    scanf("%d",&valor);
    rese=valor;
    aux=valor;
    for(i=1;i<n;i++){
        scanf("%c%d",&op,&valor);
        switch(op){
        case '+':
            rese+=valor;
            resc+=aux;
            aux=valor;
            break;
        case '*':
            rese*=valor;
            aux*=valor;
            break;
        }
    }

    resc+=aux;
    scanf("%d",&resp);

    if(resp==resc) printf("Correto, Joca!\n");
    else if(resp==rese) printf("Multiplicar antes de somar, Joca.\n");
    else printf("Errado.\n");

    return 0;
}
