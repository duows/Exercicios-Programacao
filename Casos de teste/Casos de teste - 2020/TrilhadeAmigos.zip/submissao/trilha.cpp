#include <bits/stdc++.h>
#include <cstdio>
#include <algorithm>
#include <bitset>
#include <queue>
#include <vector>
#include <climits>
#include <string>
#include <sstream>

using namespace std;

typedef     pair<int,int>       ii;

const int MAXN = 1e5 + 3;
const int INF = INT_MAX;

vector<vector<ii> > adjList;
int n, dist[MAXN], par[MAXN];
bitset<MAXN> isDone;

bool Calcular_Rota(int s, int t)
{
    priority_queue<ii, vector<ii>, greater<ii> > pq;
    fill(dist, dist+n+1, INF);
    pq.push(ii(0, s));
    dist[s] = 0;
    par[s] = -1;

    while(!pq.empty()) {
        int u = pq.top().second; pq.pop();
        if(u == t) return true;
        isDone[u] = true;
        
        for(int i=0; i<adjList[u].size(); i++)
        {
        	std::vector<std::pair<int,int> > pr = adjList[u];
        		
			int v = pr[i].first, w = pr[i].second;
			
            if(!isDone[v] && dist[u] + w < dist[v]) {
                dist[v] = dist[u] + w;
                pq.push(ii(dist[v], v));
                par[v] = u;
            }
		}
    }
    return false;
}


int main()
{
    int cont=2,peso;
	stringstream aux;
	
	string s1,b1;
    int m,s=1,b=2;

    cin>>n>>m;
    cin>>s1>>b1;

    string Matrix[m][3];
    int MatrixNumber[m][3];
    string Rotulo[n+20];
    int ID[n+20];

    Rotulo[0] = s1;
    ID[0]=1;
    Rotulo[1]= b1;
    ID[1]=2;

    adjList.resize(n+3);

    int u, v, w;


    //leitura dos pares de ligacoes
    for (int i = 0; i < m; i++){
    	cin>>Matrix[i][0]>>Matrix[i][1]>>Matrix[i][2];
	}
                
    int sinal=0;
    for (int i = 0; i < m; i++){
         	 for(int k=0;k<cont;k++){
         	    if(Matrix[i][0].compare(Rotulo[k])==0){
         	    	sinal= 1;
				}		
			 }
         	 if(sinal==0){
					Rotulo[cont] = Matrix[i][0];
             		ID[cont] = cont+1;
             		cont++;
			 }
             sinal=0;  	  
    }
    
    sinal=0;
    for (int i = 0; i < m; i++){
         	 for(int k=0;k<cont;k++){
         	    if(Matrix[i][1].compare(Rotulo[k])==0){
         	    	sinal= 1;
				}
			 }
         	 if(sinal==0){
         
					Rotulo[cont] = Matrix[i][1];
             		ID[cont] = cont+1;
             		cont++;
			 }
             sinal=0;  	  
    }

    //rotulando as ligacoes como inteiros
    
       for (int i = 0; i < m; i++){
       	 for(int j=0;j<n;j++){  
            if(Matrix[i][0].compare(Rotulo[j])==0){
                   MatrixNumber[i][0] = ID[j];
                   aux << Matrix[i][2];  
  				   aux >> peso;
                   MatrixNumber[i][2] = peso;
            }
            if(Matrix[i][1].compare(Rotulo[j])==0){
                   MatrixNumber[i][1] = ID[j];
                   aux << Matrix[i][2];  
  				   aux >> peso;
                   MatrixNumber[i][2] = peso;
            }
         }
       }
     
    //inserindo as ligacoes no grafo
    for (int i = 0; i <m; i++){
                u = MatrixNumber[i][0];
                v = MatrixNumber[i][1];
                w = MatrixNumber[i][2];
                adjList[u].push_back(ii(v, w));
                adjList[v].push_back(ii(u, w));
    }
    //calculando a rota e exibindo percurso
    if(Calcular_Rota(s, b)) {
        vector<int> path;
        printf("Percurso: ");
        for(v = b; v != -1; v = par[v]) path.push_back(v);

        for(int i = path.size()-1; i > 0; --i){
            for (int j = 0; j < m; j++){
               if(path[i]==ID[j]){
                   cout<<Rotulo[j]+"--> ";
               }
            }
        }
        for (int j = 0; j < m; j++){
               if(path[0]==ID[j]){
                   cout<<Rotulo[j]+"\n";
               }
        }
    }
    else puts("-1");
    return 0;
}
