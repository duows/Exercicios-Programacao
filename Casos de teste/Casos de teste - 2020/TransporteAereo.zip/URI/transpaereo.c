#include <stdio.h>

int main(){

    char poltrona[2][8];
    int  l, c, pas, carga, totalPas = 0, sairP=0, sairC = 0, colP, linP, totalCarga = 0, posL =0, posC =0;
    float totalPagar = 0.0;
    scanf ("%d %d", &pas, &carga);



    // COLOCAR TUDO COMO V
    for (l = 0; l < 8 ; l++){
        for (c = 0; c < 2; c++){
          poltrona[c][l] = 'V';
        }
    }



     // VERIFICANDO PASSAGEIRO
    if (pas > 0){
        totalPagar = pas * 498.00;
            for (linP = 0; linP < 8 ; linP++){
                for (colP = 0; colP < 2; colP++){
                   if (totalPas <= pas-1){
                        poltrona[colP][linP] = 'P';
                        totalPas++;
                   }else{
                        sairP = 1;
                        posL = linP;
                        posC = colP;
                        break;
                   }
                }
                if (sairP == 1){
                    break;
                }
            }
   }

   // VERIFICANDO CARGA
   if (carga > 0){
        totalPagar = totalPagar + (carga * 6.35);
        // Calculando quantidade de poltronas
        int cargaPoltrona = carga / 100;

        if (carga % 100 > 0){
            cargaPoltrona++;
        }

            for (l=posL; l<8 ; l++){
                for (c = posC; c < 2; c ++){
                        posC = 0;
                        posL = 0;
                   if (totalCarga <= cargaPoltrona-1){
                        poltrona[c][l] = 'C';
                        totalCarga++;
                   }else{
                        sairC = 1;
                        break;
                   }
                }
                if (sairC == 1){
                     break;
                }
            }

   }

    printf("%.2f", totalPagar);
    // IMPRIMINDO O MAPA DE ASSENTO
    for (l = 0; l < 2 ; l ++){
            printf("\n");
        for (c = 0; c < 8; c ++){

            printf("%c", poltrona[l][c]);
        }
    }
    return 0;
}
