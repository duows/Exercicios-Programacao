#include <stdio.h>

int main()
{
    int utis, x_in, x_out, atual, fase;
    int v_fases[4] = {0};
    double taxa;

    // numero de utis disponiveis e situacao atual no hospital
    scanf("%d%d", &utis, &atual);

    scanf("%d%d", &x_in, &x_out);
    while ((x_in > 0) || (x_out > 0))
    {
        atual += x_in - x_out;
        taxa = (double)atual / utis;
        if (taxa > 0.8)
            fase = 1;
        else if (taxa >= 0.7)
            fase = 2;
        else if (taxa >= 0.6)
            fase = 3;
        else
            fase = 4;
        v_fases[fase - 1]++;

        scanf("%d%d", &x_in, &x_out);
    }

    for (fase = 0; fase < 4; fase++)
    {
        printf("Fase %d: %d semana(s)\n", fase + 1, v_fases[fase]);
    }
    return 0;
}
