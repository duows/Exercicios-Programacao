a, b = input().split()
a = int(a) # leitos de UTI disponiveis
b = int(b) # situação inicial

x, y = input().split()

fase1 = 0
fase2 = 0
fase3 = 0
fase4 = 0

while(not(x == '0' and y == '0')):
	x = int(x)
	y = int(y)

	b = b + x - y
	perc = b * 100 / a

	if(perc > 80.0):
		fase1 = fase1 + 1
	elif(perc >= 70.0):
		fase2 = fase2 + 1
	elif(perc >= 60.0):
		fase3 = fase3 + 1
	else:
		fase4 = fase4 + 1

	x, y = input().split()

print("Fase 1:", fase1, "semana(s)")
print("Fase 2:", fase2, "semana(s)")
print("Fase 3:", fase3, "semana(s)")
print("Fase 4:", fase4, "semana(s)")

