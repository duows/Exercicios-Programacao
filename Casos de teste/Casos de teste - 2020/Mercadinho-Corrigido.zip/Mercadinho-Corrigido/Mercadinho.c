#include <stdio.h>
#include <math.h>

int main()
{
	int idade, qntP; // Valores de entrada 
	float vCompra; // Valores de entrada
	
	float pDesc, valorF; // Valores de sa�da 
	
	scanf("%i", &idade); // Idade do Cliente
	scanf("%i", &qntP); // Quantidade de Produtos da Promo��o
	scanf("%f", &vCompra); // Valor final da Compra
	
	float aux = 0;

	if(qntP == 0)
		printf("%.2f\n0.00%%\n", vCompra);
	else{
		pDesc = ((float)idade/4) + (qntP*2);
		aux = (float)((float)pDesc/100)*vCompra;
		valorF = vCompra - aux;
		
		printf("%.2f\n%.2f%%\n", valorF, pDesc);
	}
	
	return 0;
}
