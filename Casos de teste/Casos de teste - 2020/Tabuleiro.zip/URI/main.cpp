#include <iostream>
using namespace std;

int main(){

    int a,m,d, tam_matriz;

    cin >> d >> m >> a;
    
    tam_matriz = d%5 + 3;

    signed long long int t[tam_matriz][tam_matriz];

    t[0][0]=a;
    t[0][1]=m;
    t[1][0]=d;

    for(int i=0;i<tam_matriz;i++){
        for(int j=0;j<tam_matriz;j++){
            
          if(!((i==0 && j==0) || (i==1 && j==0) || (i==0 && j==1))){               
                if(i==0 && j>1){
                    t[i][j] = t[i][j-1]+j;
                }
                else if(j==0 && i>1){
                    t[i][j] = t[i-1][j]+i;
                }
                else{
                    t[i][j]=t[i][j-1]+t[i-1][j-1]+t[i-1][j];                                    
                }
          }
        }
    }
   
    cout << t[tam_matriz-1][tam_matriz-1] << endl;

    return(0);
}